# Mis Stickers: app Android de packs de stickers para WhatsApp

Incluye 2 packs originales (Caritas y Frases) con 6 stickers cada uno, generados en código.

## Cómo probarla
1. Abre esta carpeta en **Android Studio** (Ladybug o más reciente) y deja que sincronice Gradle.
2. Conecta un teléfono Android con WhatsApp instalado (o usa un emulador con WhatsApp).
3. Pulsa **Run**. En la app toca **Añadir a WhatsApp** en cada pack.

## Cómo añadir tus propios stickers
1. Pon tus imágenes en `app/src/main/assets/<id_del_pack>/` con estos requisitos de WhatsApp:
   - Stickers: **WebP, 512×512 px, fondo transparente, menos de 100 KB** (animados: menos de 500 KB).
   - Icono del pack (`tray.png`): **PNG, 96×96 px, menos de 50 KB**.
   - Cada pack debe tener entre **3 y 30 stickers**, con 1 a 3 emojis cada uno.
2. Regístralos en `app/src/main/assets/contents.json`.
3. Si cambias las imágenes de un pack ya publicado, sube su `image_data_version`.

## Antes de publicar
- Cambia `applicationId` y `namespace` en `app/build.gradle.kts` y renombra el paquete.
- Rellena `publisher_email`, `privacy_policy_website` y los enlaces de tienda en `contents.json`.
- Los assets se mantienen **sin comprimir** (`noCompress` en Gradle): WhatsApp los lee con `openFd()`.

## Sobre Facebook
Facebook no ofrece una API pública para packs de stickers de terceros. Los mismos archivos WebP/PNG se pueden compartir como imágenes, pero no se instalan como pack.

## Compilar sin Android Studio (desde el teléfono)
1. Crea una cuenta gratis en github.com y un repositorio nuevo.
2. Sube el contenido de esta carpeta (incluida `.github`) con "Add file > Upload files".
3. Ve a la pestaña **Actions**, abre "Compilar APK" y espera ~5 minutos.
4. Entra a la ejecución terminada, descarga **MisStickers-apk** (ZIP), extrae el `.apk` e instálalo.
