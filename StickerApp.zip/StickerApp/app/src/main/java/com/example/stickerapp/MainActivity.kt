package com.example.stickerapp

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private companion object {
        const val ACTION_ENABLE = "com.whatsapp.intent.action.ENABLE_STICKER_PACK"
        const val EXTRA_ID = "sticker_pack_id"
        const val EXTRA_AUTHORITY = "sticker_pack_authority"
        const val EXTRA_NAME = "sticker_pack_name"
        const val EXTRA_VALIDATION_ERROR = "validation_error"
        val WHATSAPP_PACKAGES = listOf("com.whatsapp", "com.whatsapp.w4b")
    }

    private val addLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_CANCELED) {
                val error = result.data?.getStringExtra(EXTRA_VALIDATION_ERROR)
                if (!error.isNullOrEmpty()) {
                    Toast.makeText(this, "${getString(R.string.add_failed)} ($error)", Toast.LENGTH_LONG).show()
                }
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val packs = StickerPackLoader.load(this)

        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(24))
        }
        packs.forEach { column.addView(packView(it)) }

        setContentView(ScrollView(this).apply { addView(column) })
    }

    private fun packView(pack: StickerPack): LinearLayout {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(28) }
        }

        card.addView(TextView(this).apply {
            text = pack.name
            textSize = 22f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        })
        card.addView(TextView(this).apply {
            text = "${pack.publisher} · ${pack.stickers.size} stickers"
            textSize = 14f
            alpha = 0.7f
        })

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(12), 0, dp(12))
        }
        pack.stickers.forEach { s ->
            row.addView(ImageView(this).apply {
                layoutParams = LinearLayout.LayoutParams(dp(80), dp(80)).apply { marginEnd = dp(8) }
                setImageBitmap(loadAssetBitmap("${pack.identifier}/${s.imageFile}"))
            })
        }
        card.addView(HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(row)
        })

        card.addView(Button(this).apply {
            text = getString(R.string.add_to_whatsapp)
            gravity = Gravity.CENTER
            setOnClickListener { addToWhatsApp(pack) }
        })
        return card
    }

    private fun addToWhatsApp(pack: StickerPack) {
        val target = WHATSAPP_PACKAGES.firstOrNull { isInstalled(it) }
        if (target == null) {
            Toast.makeText(this, R.string.whatsapp_missing, Toast.LENGTH_LONG).show()
            return
        }
        val intent = Intent().apply {
            action = ACTION_ENABLE
            putExtra(EXTRA_ID, pack.identifier)
            putExtra(EXTRA_AUTHORITY, StickerContentProvider.authority(packageName))
            putExtra(EXTRA_NAME, pack.name)
            setPackage(target)
        }
        try {
            addLauncher.launch(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, R.string.add_failed, Toast.LENGTH_LONG).show()
        }
    }

    private fun isInstalled(pkg: String): Boolean = try {
        packageManager.getPackageInfo(pkg, 0)
        true
    } catch (e: PackageManager.NameNotFoundException) {
        false
    }

    private fun loadAssetBitmap(path: String) =
        assets.open(path).use { BitmapFactory.decodeStream(it) }

    private fun Context.dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
