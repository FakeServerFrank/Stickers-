package com.example.stickerapp

import android.content.ContentProvider
import android.content.ContentValues
import android.content.UriMatcher
import android.content.res.AssetFileDescriptor
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import java.io.FileNotFoundException

/**
 * Proveedor que WhatsApp consulta para descubrir los packs y leer sus imágenes.
 * Sigue el contrato oficial de la API de stickers de WhatsApp para Android.
 */
class StickerContentProvider : ContentProvider() {

    companion object {
        const val METADATA = "metadata"
        const val STICKERS = "stickers"
        const val STICKERS_ASSET = "stickers_asset"

        private const val CODE_METADATA = 1
        private const val CODE_METADATA_SINGLE = 2
        private const val CODE_STICKERS = 3
        private const val CODE_STICKERS_ASSET = 4

        // Columnas de metadatos del pack
        const val STICKER_PACK_IDENTIFIER = "sticker_pack_identifier"
        const val STICKER_PACK_NAME = "sticker_pack_name"
        const val STICKER_PACK_PUBLISHER = "sticker_pack_publisher"
        const val STICKER_PACK_ICON = "sticker_pack_icon"
        const val ANDROID_PLAY_STORE_LINK = "android_play_store_link"
        const val IOS_APP_STORE_LINK = "ios_app_download_link"
        const val PUBLISHER_EMAIL = "sticker_pack_publisher_email"
        const val PUBLISHER_WEBSITE = "sticker_pack_publisher_website"
        const val PRIVACY_POLICY_WEBSITE = "sticker_pack_privacy_policy_website"
        const val LICENSE_AGREEMENT_WEBSITE = "sticker_pack_license_agreement_website"
        const val IMAGE_DATA_VERSION = "image_data_version"
        const val AVOID_CACHE = "whatsapp_will_not_cache_stickers"
        const val ANIMATED_STICKER_PACK = "animated_sticker_pack"

        // Columnas de cada sticker
        const val STICKER_FILE_NAME = "sticker_file_name"
        const val STICKER_FILE_EMOJI = "sticker_emoji"
        const val STICKER_ACCESSIBILITY_TEXT = "sticker_accessibility_text"

        fun authority(packageName: String) = "$packageName.stickercontentprovider"

        fun packUri(packageName: String, identifier: String): Uri =
            Uri.Builder().scheme("content").authority(authority(packageName))
                .appendPath(METADATA).appendPath(identifier).build()
    }

    private val matcher = UriMatcher(UriMatcher.NO_MATCH)

    override fun onCreate(): Boolean {
        val authority = authority(context!!.packageName)
        matcher.addURI(authority, METADATA, CODE_METADATA)
        matcher.addURI(authority, "$METADATA/*", CODE_METADATA_SINGLE)
        matcher.addURI(authority, "$STICKERS/*", CODE_STICKERS)
        matcher.addURI(authority, "$STICKERS_ASSET/*/*", CODE_STICKERS_ASSET)
        return true
    }

    override fun query(
        uri: Uri,
        projection: Array<String>?,
        selection: String?,
        selectionArgs: Array<String>?,
        sortOrder: String?,
    ): Cursor {
        val packs = StickerPackLoader.load(context!!)
        return when (matcher.match(uri)) {
            CODE_METADATA -> metadataCursor(uri, packs)
            CODE_METADATA_SINGLE -> {
                val id = uri.lastPathSegment
                metadataCursor(uri, packs.filter { it.identifier == id })
            }
            CODE_STICKERS -> stickersCursor(uri, packs.firstOrNull { it.identifier == uri.lastPathSegment })
            else -> throw IllegalArgumentException("URI desconocida: $uri")
        }
    }

    private fun metadataCursor(uri: Uri, packs: List<StickerPack>): Cursor {
        val cursor = MatrixCursor(
            arrayOf(
                STICKER_PACK_IDENTIFIER, STICKER_PACK_NAME, STICKER_PACK_PUBLISHER, STICKER_PACK_ICON,
                ANDROID_PLAY_STORE_LINK, IOS_APP_STORE_LINK, PUBLISHER_EMAIL, PUBLISHER_WEBSITE,
                PRIVACY_POLICY_WEBSITE, LICENSE_AGREEMENT_WEBSITE, IMAGE_DATA_VERSION,
                AVOID_CACHE, ANIMATED_STICKER_PACK,
            )
        )
        for (p in packs) {
            cursor.newRow()
                .add(p.identifier)
                .add(p.name)
                .add(p.publisher)
                .add(p.trayImageFile)
                .add(p.androidPlayStoreLink)
                .add(p.iosAppStoreLink)
                .add(p.publisherEmail)
                .add(p.publisherWebsite)
                .add(p.privacyPolicyWebsite)
                .add(p.licenseAgreementWebsite)
                .add(p.imageDataVersion)
                .add(if (p.avoidCache) 1 else 0)
                .add(if (p.animated) 1 else 0)
        }
        cursor.setNotificationUri(context!!.contentResolver, uri)
        return cursor
    }

    private fun stickersCursor(uri: Uri, pack: StickerPack?): Cursor {
        val cursor = MatrixCursor(arrayOf(STICKER_FILE_NAME, STICKER_FILE_EMOJI, STICKER_ACCESSIBILITY_TEXT))
        pack?.stickers?.forEach { s ->
            cursor.newRow()
                .add(s.imageFile)
                .add(s.emojis.joinToString(","))
                .add("")
        }
        cursor.setNotificationUri(context!!.contentResolver, uri)
        return cursor
    }

    override fun openAssetFile(uri: Uri, mode: String): AssetFileDescriptor? {
        if (matcher.match(uri) != CODE_STICKERS_ASSET) return null
        val segments = uri.pathSegments
        if (segments.size != 3) return null
        val identifier = segments[1]
        val fileName = segments[2]
        val pack = StickerPackLoader.load(context!!).firstOrNull { it.identifier == identifier }
            ?: throw FileNotFoundException("Pack no encontrado: $identifier")
        // Solo se sirven archivos declarados en el pack (evita path traversal).
        val allowed = pack.stickers.any { it.imageFile == fileName } || pack.trayImageFile == fileName
        if (!allowed) throw FileNotFoundException("Archivo no declarado: $fileName")
        return try {
            context!!.assets.openFd("$identifier/$fileName")
        } catch (e: java.io.IOException) {
            throw FileNotFoundException(e.message)
        }
    }

    override fun getType(uri: Uri): String? = when (matcher.match(uri)) {
        CODE_METADATA -> "vnd.android.cursor.dir/vnd.${authority(context!!.packageName)}.$METADATA"
        CODE_METADATA_SINGLE -> "vnd.android.cursor.item/vnd.${authority(context!!.packageName)}.$METADATA"
        CODE_STICKERS -> "vnd.android.cursor.dir/vnd.${authority(context!!.packageName)}.$STICKERS"
        CODE_STICKERS_ASSET -> "image/webp"
        else -> throw IllegalArgumentException("URI desconocida: $uri")
    }

    // Solo lectura
    override fun insert(uri: Uri, values: ContentValues?): Uri? = throw UnsupportedOperationException("Solo lectura")
    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<String>?): Int =
        throw UnsupportedOperationException("Solo lectura")
    override fun update(uri: Uri, values: ContentValues?, selection: String?, selectionArgs: Array<String>?): Int =
        throw UnsupportedOperationException("Solo lectura")
}
