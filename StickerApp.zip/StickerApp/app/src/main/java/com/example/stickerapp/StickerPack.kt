package com.example.stickerapp

import android.content.Context
import org.json.JSONObject

data class Sticker(
    val imageFile: String,
    val emojis: List<String>,
)

data class StickerPack(
    val identifier: String,
    val name: String,
    val publisher: String,
    val trayImageFile: String,
    val publisherEmail: String,
    val publisherWebsite: String,
    val privacyPolicyWebsite: String,
    val licenseAgreementWebsite: String,
    val imageDataVersion: String,
    val avoidCache: Boolean,
    val animated: Boolean,
    val androidPlayStoreLink: String,
    val iosAppStoreLink: String,
    val stickers: List<Sticker>,
)

object StickerPackLoader {

    @Volatile
    private var cache: List<StickerPack>? = null

    /** Lee assets/contents.json (una sola vez) y devuelve los packs. */
    fun load(context: Context): List<StickerPack> {
        cache?.let { return it }
        synchronized(this) {
            cache?.let { return it }
            val text = context.applicationContext.assets.open("contents.json")
                .bufferedReader(Charsets.UTF_8).use { it.readText() }
            val root = JSONObject(text)
            val play = root.optString("android_play_store_link")
            val ios = root.optString("ios_app_store_link")
            val packsJson = root.getJSONArray("sticker_packs")
            val packs = (0 until packsJson.length()).map { i ->
                val p = packsJson.getJSONObject(i)
                val stickersJson = p.getJSONArray("stickers")
                val stickers = (0 until stickersJson.length()).map { j ->
                    val s = stickersJson.getJSONObject(j)
                    val emojisJson = s.optJSONArray("emojis")
                    val emojis = if (emojisJson == null) emptyList()
                    else (0 until emojisJson.length()).map { emojisJson.getString(it) }
                    Sticker(s.getString("image_file"), emojis)
                }
                StickerPack(
                    identifier = p.getString("identifier"),
                    name = p.getString("name"),
                    publisher = p.getString("publisher"),
                    trayImageFile = p.getString("tray_image_file"),
                    publisherEmail = p.optString("publisher_email"),
                    publisherWebsite = p.optString("publisher_website"),
                    privacyPolicyWebsite = p.optString("privacy_policy_website"),
                    licenseAgreementWebsite = p.optString("license_agreement_website"),
                    imageDataVersion = p.optString("image_data_version", "1"),
                    avoidCache = p.optBoolean("avoid_cache", false),
                    animated = p.optBoolean("animated_sticker_pack", false),
                    androidPlayStoreLink = play,
                    iosAppStoreLink = ios,
                    stickers = stickers,
                )
            }
            cache = packs
            return packs
        }
    }
}
